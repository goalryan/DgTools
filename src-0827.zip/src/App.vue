<template>
    <div v-if="!isEdit" style="flex:1;flex-direction: row">
        <el-row>
            <el-col :span="24">
                <el-button size="small" @click="addOrder">添加账单</el-button>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="24">
                <el-select v-model="docNo" placeholder="请选择账单" @change="selectDocNo">
                    <el-option
                            v-for="item in docNoList"
                            :key="item"
                            :label="item"
                            :value="item">
                    </el-option>
                </el-select>
            </el-col>
        </el-row>
    </div>

    <div v-else="">
        <el-form :inline="true" class="demo-form-inline">
            <el-form-item label="账单号:">{{order.docNo}}</el-form-item>
            <el-form-item label="汇率:">
                <el-input v-model="order.taxRate" placeholder="请输入汇率" @change="changeTaxRate"></el-input>
            </el-form-item>
        </el-form>
        <el-row>
            <el-col :span="12">
                <el-button size="small" @click="saveDoc">保存账单</el-button>
                <el-button size="small" @click="closeDoc">关闭账单</el-button>
                <el-button size="small" @click="delDoc">删除账单</el-button>
            </el-col>
        </el-row>
        <el-table
                :data="order.customers" :row-key="getRowKeys" :expand-row-keys="expands" style="width: 100%">
            <el-table-column type="expand">
                <template scope="scope">
                    <child-list :products="scope.row.products" :taxRate="order.taxRate"
                                @updateCustomer="updateCustomer(scope.$index)"></child-list>
                </template>
            </el-table-column>
            <el-table-column label="客户名称">
                <template scope="scope">
                    <el-input v-model="scope.row.name" size="small" placeholder="请输入客户名称"></el-input>
                </template>
            </el-table-column>
            <el-table-column label="数量" prop="quantity">
            </el-table-column>
            <el-table-column label="成本" prop="inTotalPrice">
            </el-table-column>
            <el-table-column label="收入" prop="outTotalPrice">
            </el-table-column>
            <el-table-column label="利润" prop="profit">
            </el-table-column>
            <el-table-column label="操作">
                <template scope="scope">
                    <el-button v-if="scope.$index === order.customers.length - 1" size="small"
                               @click="addCustomer(scope.$index+1)">添加





                    </el-button>
                    <el-button size="small" type="danger" @click="delCustomer(scope.$index)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    import ChildList from './childList.vue';
    import DocHeader from './docHeader.vue';
    import store from './store.js';
    export default {
        name: 'app',
        components: {
            ChildList,
            DocHeader
        },
        data () {
            return {
                isEdit: false,
                docNo: '',
                docNoList: [],
                order: {
                    docNo: '',
                    taxRate: '1',
                    customers: []
                },
                // 获取row的key值
                getRowKeys(row) {
                    return row.id;
                },
                // 要展开的行，数值的元素是row的key值
                expands: []
            }
        },
        computed: {
            /**
             * 是否最后一行
             * @param index
             * @returns {boolean}
             */
            isLastRow: function (index) {
                return index === this.order.customers.length - 1;
            }
        },
        mounted() {
            // 在这里你想初始化的时候展开哪一行都可以了
            // this.expands.push(this.order.customers[0].id);
            this.fetchDocNoList();
        },
        methods: {
            addOrder(){
                this.isEdit = true;
                this.initDocNo();
                this.order.docNo = this.docNo;
                this.order.customers = [this.initCustomer(0)];
            },
            fetchDocNoList() {
                this.docNoList = store.fetchDocNoList();
            },
            selectDocNo(){
                this.isEdit = true;
                this.order = store.fetchDoc(this.docNo);
                console.log(this.order);
            },
            initCustomer(){
                return {
                    id: 0,
                    name: '',
                    quantity: '',
                    inTotalPrice: '',
                    outTotalPrice: '',
                    profit: '',
                    products: [
                        {
                            name: '',
                            quantity: '',
                            inUnitPrice: '',
                            outUnitPrice: '',
                            inTotalPrice: '',
                            outTotalPrice: '',
                            profit: '',
                        },
                    ]
                }
            },
            expandRow() {
            },
            addCustomer(index) {
                this.isEdit = true;
                this.initDocNo();
                this.order.docNo = this.docNo;
                this.order.customers.push(this.initCustomer(index));
            },
            delCustomer(index) {
                if (this.order.customers.length === 1) {
                    this.$message({message: '必须保留一个客户', type: 'warning'});
                    return;
                }
                this.confirmDialog(this.order.customers[index].name, () => {
                    this.order.customers.splice(index, 1);
                })
            },
            updateCustomer(index) {
                let quantity = 0;
                let inTotalPrice = 0;
                let outTotalPrice = 0;
                let profit = 0;
                this.order.customers[index].products.forEach((item) => {
                    quantity += parseFloat(item.quantity);
                    inTotalPrice += parseFloat(item.inTotalPrice);
                    outTotalPrice += parseFloat(item.outTotalPrice);
                    profit += parseFloat(item.profit);
                });
                this.order.customers[index].quantity = quantity;
                this.order.customers[index].inTotalPrice = inTotalPrice;
                this.order.customers[index].outTotalPrice = outTotalPrice;
                this.order.customers[index].profit = profit;
            },
            changeTaxRate() {
                this.order.customers.forEach((customer) => {
                    let totalProfit = 0;
                    customer.products.forEach((product) => {
                        product.profit = (product.outTotalPrice - product.inTotalPrice * this.order.taxRate).toFixed(0);
                        totalProfit += parseFloat(product.profit);
                    });
                    customer.profit = totalProfit;
                });
            },
            confirmDialog(customerName, callback) {
                this.$confirm(`确定删除客户【${customerName}】?`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    callback();
                }).catch(() => {
                    this.$message({type: 'success', message: '已取消删除'});
                });
            },
            initDocNo() {
                let date = new Date();
                let year = date.getFullYear();
                let month = date.getMonth() + 1;
                month = month < 10 ? `0${month}` : month;
                let day = date.getDate() < 10 ? `0${date.getMonth()}` : date.getDate();
                this.docNo = `${year}${month}${day}`;
                console.log(this.docNo);
            },
            saveDoc(){
                store.saveDoc(this.order, this.docNo);
                this.$message({message: '保存账单成功', type: 'success'});
            },
            delDoc() {
                store.delDoc(this.docNo);
                this.$message({message: '删除账单成功', type: 'success'});
                this.fetchDocNoList();
                this.isEdit = false;
                this.docNo = '';

            },
            closeDoc(){
                this.isEdit = false;
                this.docNo = '';
                this.fetchDocNoList();
            }
        }
    }
</script>

<style>

    .el-row {
        margin-bottom: 20px;

    &
    :last-child {
        margin-bottom: 0;
    }

    }

    .el-col {
        border-radius: 4px;
    }

    .demo-table-expand {
        font-size: 0;
    }

    .demo-table-expand label {
        width: 90px;
        color: #99a9bf;
    }

    .demo-table-expand .el-form-item {
        margin-right: 0;
        margin-bottom: 0;
        width: 50%;
    }
</style>
